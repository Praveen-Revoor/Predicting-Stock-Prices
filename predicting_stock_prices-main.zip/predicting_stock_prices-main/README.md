# Predicting Popular Social Media Stock Prices
Class Project for CS-549 Machine Learning at San Diego State University
